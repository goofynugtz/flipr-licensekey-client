from licensekeygentest.main import library
